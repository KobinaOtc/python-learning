# Python learning for beginers

This is a group of exercises to show the gradual progess made durring my first course in python programing.

## Day 1 progress

1) Variables and expressions.

2) Python Frunctions

3) Conditional structures

4) Loops

5) Classes

## Notes